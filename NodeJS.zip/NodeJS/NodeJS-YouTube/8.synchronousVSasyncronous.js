// Synchronous  VS  Asyncronous
const fs = require("fs");

fs.writeFile("fileName.txt", "fileData") // Asyncronous Method