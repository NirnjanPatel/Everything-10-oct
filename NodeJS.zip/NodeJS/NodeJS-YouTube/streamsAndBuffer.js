// #21: Streams and Buffer in Node

// Streams = ex. IPL Live streaming     
// Readable − Stream which is used for read operation.
// Writable − Stream which is used for write operation.
// Duplex − Stream which can be used for both read and write operation.
// Transform − A type of duplex stream where the output is computed based on input.

// Each type of streams is an EvnetEmmiter instance

// data - available to read
// end = no more data is available to read
// finish = 
// error = 

// Buffer = In Node Js, buffers are used to store raw binary data.A buffer represents a chunk of memory that is allocated on our computer.The size of the buffer, once set, cannot be changed.A buffer is used to store bytes.

