// Merging of two array 

function array() {

}