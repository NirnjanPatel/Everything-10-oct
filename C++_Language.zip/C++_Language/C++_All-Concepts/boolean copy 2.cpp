// Premitive Data Type (Bool/Boolean)
#include <iostream>
using namespace std;
int main()
{
}