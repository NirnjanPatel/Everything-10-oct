// Additionn of two values
#include <iostream>
using namespace std;
int main()
{
    int a, b, c;
    cout << "Enter Two Values a & b= ";
    cin >> a >> b;
    c = a + b;
    cout << "Value of a = " << a;
    cout << "\nValue of b = " << a;
    cout << "\nAddition = " << c << endl;
}