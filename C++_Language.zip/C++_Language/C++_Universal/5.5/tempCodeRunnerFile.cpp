   // cout << "Multiplication = " << setData() << endl;
    // cout << "Multiplication = " << multi() << endl;