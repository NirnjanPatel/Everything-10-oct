// Default Constructor
#include <iostream>
using namespace std;
class Constructor
{
public:
};
int main()
{

    return 0;
}