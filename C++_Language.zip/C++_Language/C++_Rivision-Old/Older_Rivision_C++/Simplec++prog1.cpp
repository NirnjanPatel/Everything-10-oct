// Simple class and object program
#include <iostream>
using namespace std;
class college
{
public:
    void show()
    {
        cout << "----Showing data of college named class----" << endl;
    }
};
int main()
{
    college data;
    data.show();
}
