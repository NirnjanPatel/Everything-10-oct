// Same functions in different types of namespaces
#include<iostream>
using namespace std;
int main()
{
    
    return 0;
}