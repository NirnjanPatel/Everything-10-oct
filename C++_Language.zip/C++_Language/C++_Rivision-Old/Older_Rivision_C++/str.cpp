// printing a string in c++
#include <iostream>
#include <stdio.h>
using namespace std;
int main()
{
    string name;
    cout << "Enter your name : ";
    getline(cin, name);
    cout << "Name : " << name << endl;
    cout << "Size of string : " << name.length() << endl;
    cout << "Size of string : " << strlen.name() << endl;
    return 0;
}