#include<iostream>
using namespace std;
int main()
{
    cout << "Hello Neer...,,,%$##@!!!!!" << endl;
    cout << "Hello Neer...,,,%$##@!!!!!\n";
    cout << "\nHello Neer...,,,%$##@!!!!!\n";
    return 0;
}