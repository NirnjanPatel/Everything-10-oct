//calculate sum of first and fourth number 
#include<stdio.h>
void main()
{
   printf("Rohit Dhamgaye "\n);
   printf("  Rohit Dhamgaye"\n);

}