#include<iostream>
#include<string.h>
using namespace std;
int main()
{
    string str;
    char name[56];
    cout << "Enter String : ";
    getline(cin,str);
    cout << "Enter Name : ";
    getline(cin,str);
    return 0;
}