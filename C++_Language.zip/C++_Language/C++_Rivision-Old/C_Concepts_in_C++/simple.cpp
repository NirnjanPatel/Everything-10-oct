#include<iostream>
using namespace std;
int main(int argc, const char** argv) 
{
    cout << "Hello Niranjan.,,,!!!!" << endl;
    cout << "Let's start c++" << endl;
    return 0;
}           