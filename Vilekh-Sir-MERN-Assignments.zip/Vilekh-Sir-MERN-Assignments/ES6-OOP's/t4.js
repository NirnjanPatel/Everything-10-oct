import TestClass from './m3.js';
var obj = new TestClass();

console.log("Module imported successfully....");
console.log("a = "+obj.a);
console.log("b = "+obj.b);

obj.demo();
obj.demo1();
