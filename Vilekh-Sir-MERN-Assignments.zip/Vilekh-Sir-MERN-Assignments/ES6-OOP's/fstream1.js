// file stream : readable

import * as fs from 'fs';
console.log("Before file operation");
var readstream = fs.createReadStream("data2.txt");
// The function fs.createReadStream() allows you to open up a readable stream in a very simple manner. 
var file_content="";
readstream.on("data",(chunk)=>{
 file_content+=chunk;
})
readstream.on("end",()=>{
 console.log(file_content);
})
readstream.on("error",(err)=>{
 console.log(err);
})
console.log("After file operation");
