import obj from './m4.js';

console.log("Module imported successfully....");
console.log("a = "+obj.a);
console.log("b = "+obj.b);

obj.demo();
obj.demo1();
