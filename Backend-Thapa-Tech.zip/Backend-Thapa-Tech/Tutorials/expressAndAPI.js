// Fetching data from Realtime API
// Creating a user API
import fs from 'fs';
import http from "http";

const server = http.createServer((req, res) => {
    // const data = fs.readFileSync(`${__dirname}/API.json`, "utf-8");
    const data = fs.readFileSync("./API.json", "utf-8");
    const objData = JSON.stringify(data);
    if (req.url == "/") {
        res.end(objData);
    }
    else if (req.url == "/userapi") {
        res.writeHead(200, { "Content-type": "application/json" });
        res.end(objData);
    }
    else {
        console.log("ERROR");
    }

});
server.listen(8000, "127.0.0.1", ()=> {
    console.log("Server Listened");
});