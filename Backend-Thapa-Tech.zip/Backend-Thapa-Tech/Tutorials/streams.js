import fs from "fs";
import http from "http";

const server = http.createServer((req, res) => {
    const rstream = fs.createReadStream("input.txt");
    rstream.on('data', (chunk) => {
        res.write(chunk);
    });
    rstream.on('end', (chunk) => {
        res.end(chunk);
        });
    rstream.on('error', (chunk) => {
        res.end("error found");
    });
}).listen(8000,"127.0.0.1");