import fs, { rmSync } from "fs";
import http from "http";

const server = http.createServer((req, res) => {
    // rstream.on('data', (chunk) => {
        //     res.write(chunk);
        // });
        // rstream.on('end', (chunk) => {
            //     res.end(chunk);
            //     });
            // rstream.on('error', (chunk) => {
                //     res.end("error found");
                // });
                
const rstream = fs.createReadStream("input.txt");
    rstream.pipe(res); 
    // fast and efficient method
}).listen(8000,"127.0.0.1");