// Creating a user API
import fs from 'fs';
import http from "http";

const server = http.createServer((req, res) => {
    // const data = fs.readFileSync(`${__dirname}/API.json`, "utf-8");
    const data = fs.readFileSync("./WeatherAPI.json", "utf-8");
    const objData = JSON.parse(data);
    if (req.url == "/") {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.write(JSON.stringify(objData));
    res.end();    }
    else if (req.url == "/userapi") {
        res.end(objData);
    }
    else {
        console.log("ERROR");
    }

    // fs.readFile("API.json", (err, data) => {
    //     res.end(data);
    //     // const objData = JSON.parse(data);
    //     // res.end(objData[0].name);
    //     console.log("API Data Fetched succesfully"); 
    // });
});
server.listen(8000, "127.0.0.1", ()=> {
    console.log("Server Listened");
});