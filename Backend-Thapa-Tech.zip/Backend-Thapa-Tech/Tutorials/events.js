// ERROR Found


// Event Module
// where we can create, fire and listen events

import http from "http";
import fs from "fs";
import EventEmitter from "events";

const event = EventEmitter();

event.emit("sayMyName");

event.on("sayMyName", () => {
    console.log("hhdhskldhklshdkl");
});

