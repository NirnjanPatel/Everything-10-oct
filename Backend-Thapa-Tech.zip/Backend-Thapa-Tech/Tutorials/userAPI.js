// Creating a user API
import fs from 'fs';
import http from "http";

const server = http.createServer((req, res) => {

    const data = fs.readFileSync("API.json", "utf-8");
    const objData = JSON.parse(data);
    fs.readFile("API.json", (err, data) => {
        res.end(data);
        // const objData = JSON.parse(data);
        // res.end(objData[0].name);
        console.log("API Data Fetched succesfully"); 
    });
}).listen(8000);