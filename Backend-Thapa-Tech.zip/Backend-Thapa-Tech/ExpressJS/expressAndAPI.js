import express from "express";
import path from "path";
import requests from "requests";

// middleware to configure template page, template engine, static files and all the paths
const staticPath = path.join(__dirname, "../ExpressJS");
const templatePath = path.join(__dirname, "./views");
// const partialPath = path.join(__dirname, "./Partials");

// To set the view engine
app.set("view engine", "ejs");
app.set("views", templatePath);
app.use(express.static(staticPath));

const app = express();

// routing
app.get("/", (req, res) => {
    res.end("<h1>Home</h1>");
});

app.get("/about", (req, res) => {
    requests("https://api.openweathermap.org/data/2.5/weather?q=${req.query.name}&appid=deeb4ec141ec8bc78a8d96c65e2429e6")
        .on("data", (chunk) => {
            const objData = JSON.parse(chunk);
            const arrData = [objData];
            console.log(`City is ${arrData[0].main} and Temporator js ${arrData[0].main.temp}`);

            res.write(realTimeData);
        })
        .on("end", (err) => {
            if (err) return console.log("Connection is closed due to errors", err);
            res, end();
    })

});
app.get("/about/*", (req, res) => {
    res.render("404"); 
});

app.listen(8000);

