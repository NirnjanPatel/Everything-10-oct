import React from "react";

export default function User() {
  return <div>This is JSX</div>; // React.createElement('div',cl,React,.createElement) without jsx
}
// can we use angular and react both
// Yes we can because react is an Library
