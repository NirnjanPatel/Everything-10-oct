var a, b, c;
a = 100;
b = 200;
c = a + b;
console.log("a = " + a);
console.log("b = " + b);
console.log("Add = " + c);