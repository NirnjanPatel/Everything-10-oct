import { mkdir, mkdtemp, mkdirSync } from 'fs';

// import * as fs from 'fs';
// fs.mkdir('./Abhi-Neer2', {}, (err) => {
// console.log(err);
mkdir('./Abhi-Neer2', {}, (err) => {
    console.log(err);
});
mkdtemp('./abhhiii', {}, (err) => {
    console.log(err);
});