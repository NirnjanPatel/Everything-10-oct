// OOP's

class Demo
{
 demoData() // function
 {
  console.log("Welcome to ES6 OOP's");    
 }        
}

var obj = new Demo(); // new keyword used to create object of a class
obj.demoData();